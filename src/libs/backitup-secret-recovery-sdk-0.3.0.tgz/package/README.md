# Backitup Secret Recovery SDK

Network-agnostic **crypto client** for the Backitup compartmented secret-recovery
scheme. It bundles the primitives a client needs — stealth meta-keys, Shamir
Secret Sharing, ECIES, stealth-address derivation — and adds the two-half split
(`K = K_nodes XOR K_friends`), the deterministic secret id, and helpers to build
the on-chain `ShareInput[]` for `BackitupSecretRecovery`.

## Scope (what it does / does not do)

This package is **crypto and definitions only**. It never touches the chain or
nodes, and it builds no EIP-712 signatures — those concerns live at the edges:

| Concern | Where |
| --- | --- |
| Split / combine keys, Shamir, ECIES, stealth addresses, `computeId`, `ShareInput[]` | **this SDK** |
| EIP-712 domains + struct definitions, nonce keys, `RoundState` (data, pinned to the contracts by test) | **this SDK** |
| The texts a node verifies signatures over (pinned to `backitup-node` by test) | **this SDK** |
| EIP-712 signing | frontend (viem), relayed by the backend |
| Node transport (`NodeClient` impl + node list) | frontend (talks to each node directly) |
| On-chain reads/writes (`addSecret`, `canDecrypt`, …) | frontend + backend relayer |

The SDK ships only the `NodeClient` **interface**; an in-memory mock used to
demonstrate the round-trip lives under `test/fixtures/`.

## Install

```bash
npm install backitup-secret-recovery-sdk
```

Peer runtime: Node.js `>=20` or a modern browser (uses Web Crypto with a Node
fallback). Built on [`viem`](https://viem.sh), `@noble/secp256k1`, `eth-crypto`
and `shamirs-secret-sharing`.

## Architecture

```
            ┌──────────────── master key K ────────────────┐
            │                                               │
   splitKeyTwoHalves(K)                                     │
            │                                               │
   ┌────────┴────────┐                              ┌───────┴────────┐
   │   nodesHalf      │                              │   friendsHalf   │
   │  (Shamir → nodes)│                              │ (Shamir + ECIES │
   │                  │                              │   → on-chain)   │
   └────────┬─────────┘                              └───────┬────────┘
            │ release iff canDecrypt(recipient,id)           │ decrypt with
            │                                                │ guardian keys
            └───────────────┬────────────────────────────────┘
                            ▼
                 combineKeyTwoHalves → K
```

- **`nodesHalf`** — Shamir-split across operator nodes; a node releases its share
  only when `canDecrypt(recipient, id) == true`.
- **`friendsHalf`** — Shamir-split among guardians, each share ECIES-encrypted to a
  guardian **stealth** public key and delivered on-chain via `ShareInput[]`.
- Neither half reveals anything about `K` on its own; you need both to rebuild it.

## API reference

Everything is exported from the package root. The main entry point is the
`BackitupSecretRecoveryClient` class; the same helpers are also exported as
standalone functions.

### `BackitupSecretRecoveryClient`

**Meta-key derivation**

| Method | Signature | Purpose |
| --- | --- | --- |
| `generateBaseSignature` | `(pin, walletClient) => Promise<string>` | Sign the canonical message (salted with `pin`) to derive keys from a connected wallet. |
| `generateKeysFromSignature` | `(signature) => Promise<StealthMetaKeyPair>` | Deterministically derive spending + viewing keys from a 65-byte signature. |

**Shamir Secret Sharing**

| Method | Signature | Purpose |
| --- | --- | --- |
| `generateShares` | `(secret, numShares, threshold) => string[]` | Split a secret into `numShares` shares; any `threshold` (at least 2) reconstruct it. An 8-byte `keccak256` tag of the secret is split along with it. |
| `generateSharesEncrypted` | `(secret, numShares, threshold, publicKeys) => Promise<string[]>` | As above, then ECIES-encrypt each share to `publicKeys[i]` (order preserved). |
| `recoverSecret` | `(shares) => string` | Reconstruct the secret from at least `threshold` shares; throws `ShareIntegrityError` when the tag does not match — a corrupted share, shares of two splits, or too few — instead of returning a wrong secret. |
| `decryptShare` | `(encryptedShare, privateKey) => Promise<string>` | Decrypt one ECIES share with its private key. |

**Stealth addresses (ERC-5564)**

Scheme 1 (SECP256k1 with view tags): the ECDH runs against the **viewing** key,
the stealth key is the spending key **plus** the hashed shared secret. Two keys,
two roles — a guardian can hand a watcher their viewing key without handing over
the ability to open anything.

A meta-address comes off the key pair; everything else is a standalone function
the client also exposes as a method.

| Function | Signature | Purpose |
| --- | --- | --- |
| `StealthMetaKeyPair#metaAddress` | `() => Hex` | The 66-byte `spend \|\| view` blob to publish to the key registry. |
| `StealthMetaKeyPair#formatMetaAddress` | `() => string` | The same value as `st:eth:0x…`. |
| `encodeStealthMetaAddress` | `({ spendingPublicKey, viewingPublicKey }) => Hex` | The same blob from two loose public keys. |
| `formatStealthMetaAddress` | `(metaAddress) => string` | Prefix a blob for display. |
| `decodeStealthMetaAddress` | `(metaAddress) => { spendingPublicKey, viewingPublicKey }` | Split one back into its two compressed keys. |
| `generateStealthAddress` | `(metaAddress, ephemeralPrivateKey?) => StealthAddressResult` | Sender: a fresh stealth address, ephemeral pubkey and view tag. The key is injectable for vectors only. |
| `checkStealthAddress` | `({ viewingPrivateKey, spendingPublicKey }, ephemeralPubKey, viewTag?) => Hex \| null` | Recipient, scanning: the address this announcement yields, or `null` when the view tag rules it out. |
| `computeStealthKey` | `({ spendingPrivateKey, viewingPrivateKey }, ephemeralPubKey) => Hex` | Recipient, spending: the private key of that address. |

Every function that takes both keys takes them in a record rather than
positionally: the two are the same type, so a swap would be a silently wrong
address rather than an error.

`checkStealthAddress` returning an address does not mean the announcement is
yours — every announcement yields one. It is yours when that address equals the
announced one.

The ERC fixes the structure but leaves the byte encoding open. This SDK hashes
the 32-byte x coordinate of the **compressed** shared point, keeps both public
keys compressed inside a meta-address, and takes the view tag as the first byte
of that hash. `test/stealth.test.ts` carries a reference vector with literal
keys and literal expected values, so an implementation in another language has
something exact to match rather than a description to interpret.

**Two-half compartmenting**

| Method | Signature | Purpose |
| --- | --- | --- |
| `splitKeyTwoHalves` | `(key, randomFn?) => TwoHalves` | Split `K` into `{ nodesHalf, friendsHalf }` (`nodesHalf` is uniform random). |
| `combineKeyTwoHalves` | `(nodesHalf, friendsHalf) => Hex` | XOR the two halves back into `K`. |

**Contract helpers**

| Method | Signature | Purpose |
| --- | --- | --- |
| `computeId` | `(owner, label) => Hex` | Deterministic secret id = `keccak256(abi.encode(owner, label))`. |
| `toShareInput` | `(stealth, shareEncrypted) => ShareInput` | Build one on-chain `ShareInput`. |
| `buildShareInputs` | `(stealths, encryptedShares) => ShareInput[]` | Zip aligned lists into the `ShareInput[]` for `addSecret` / `reshare`. |

**Contract mirrors** (standalone, data only)

| Export | Purpose |
| --- | --- |
| `SECRET_RECOVERY_DOMAIN`, `KEY_REGISTRY_DOMAIN` | `{ name, version }` of each contract's EIP-712 domain; add your `chainId` and `verifyingContract`. |
| `TYPES` | The ten structs (`Share`, `AddSecret`, `Reshare`, `SetRecoveryPolicy`, `InitiateRecovery`, `ApproveRecovery`, `CancelRecovery`, `RevokeSecret`, `RegisterKeys`, `InvalidateNonce`) as `{ name, type }[]`, in the contracts' field order. viem's `signTypedData` takes the whole table; ethers' wants only the primary struct and `Share` where it is referenced, as mutable arrays (`[...TYPES.Share]`). |
| `TypedMessages`, `…Message` | The message shape per primary type (`bigint` for `uint256`, `Hex` for `address`/`bytes`). |
| `nonceKey(id)`, `registryNonceKey(scheme)` | The key to read `nonces(signer, key)` with: `uint192(uint256(id))` for a secret's payloads, the scheme for a registration. |
| `RoundState` | `None`/`Voting`/`TimeLock`/`Window`/`Expired`, as `roundState(id)` returns it; `RoundState[x]` is the name. |

`test/typedData.test.ts` holds the literal type strings of the contracts'
`*_TYPEHASH` constants and checks every entry of `TYPES` against them, so the
copies cannot drift from the contract without the suite failing.

### Standalone functions

Exported directly (the client methods delegate to these):

- `xorHex(a, b): Hex` — byte-wise XOR of two equal-length hex strings.
- `splitKeyTwoHalves(key, randomFn?): TwoHalves`
- `combineKeyTwoHalves(nodesHalf, friendsHalf): Hex`
- `computeId(owner, label): Hex`
- `toShareInput(stealth, shareEncrypted): ShareInput`
- `buildShareInputs(stealths, encryptedShares): ShareInput[]`
- `encodeStealthMetaAddress`, `formatStealthMetaAddress`, `decodeStealthMetaAddress`
- `generateStealthAddress`, `checkStealthAddress`, `computeStealthKey`
- `buildNodeDepositMessage(m)`, `buildNodeReleaseMessage(m)` — the node protocol
  v2 texts an owner signs to deposit a node-half share and a recipient signs to
  ask for it back; `nodeShareDigest(share)` is the digest a deposit names.

### Classes

- `StealthMetaKeyPair({ spendingPrivateKey, viewingPrivateKey })` — holds
  `spendingKeyPair` and `viewingKeyPair`.
- `SingleKeyPair(privateKey)` — holds `privatekey` and a viem `account`.

### Types

| Type | Shape / meaning |
| --- | --- |
| `Hex` | `` `0x${string}` `` |
| `StealthAddressResult` | `{ address, publicKey, ephemeralPubKey, viewTag }` |
| `ScanningKeys` / `SpendingKeys` | the recipient's key records: `{ viewingPrivateKey, spendingPublicKey }` / `{ spendingPrivateKey, viewingPrivateKey }` |
| `ShareInput` | `{ stealthAddress, ephemeralPubKey, shareEncrypted }` — mirrors the on-chain struct |
| `TwoHalves` | `{ nodesHalf, friendsHalf }` |
| `NodeRef` | `{ id, url? }` — a node endpoint |
| `NodeAddShareRequest` | `{ id, version, share }` — deposit payload |
| `NodeGetShareRequest` | `{ id, recipient }` — release request |
| `NodeClient` | `{ add(node, req), get(node, req) }` — node transport interface |
| `CanDecryptFn` | `(account, id) => Promise<boolean> \| boolean` — mirrors on-chain `canDecrypt` |

### Constants

- `GENERATE_STEALTH_ADDRESS_MESSAGE` — the template message signed by
  `generateBaseSignature` (contains a `{pin}` placeholder).
- `STEALTH_META_PREFIX` — `st:eth:`, the ERC-5564 display prefix.

## End-to-end flows

### Backup

```ts
import { BackitupSecretRecoveryClient } from 'backitup-secret-recovery-sdk';

const client = new BackitupSecretRecoveryClient();

// 1. derive stealth meta-keys from a wallet signature + PIN
const sig = await client.generateBaseSignature(pin, walletClient);
const metaKeys = await client.generateKeysFromSignature(sig);

// 2. deterministic id (same value the contract computes)
const id = client.computeId(owner, 'messenger-account');

// 3. split the master key into two compartments
const { nodesHalf, friendsHalf } = client.splitKeyTwoHalves(K);

// 4. friends half -> per-guardian stealth address -> Shamir + ECIES -> ShareInput[]
//    guardianMetaAddresses are what the key registry returns: spend || view.
const stealths = guardianMetaAddresses.map((meta) => client.generateStealthAddress(meta));
const friendShares = await client.generateSharesEncrypted(
  friendsHalf,
  stealths.length,
  threshold,
  stealths.map((s) => s.publicKey),
);
const shareInputs = client.buildShareInputs(stealths, friendShares);
// -> feed shareInputs to addSecret (EIP-712 signed on the FE, relayed by backend)

// 5. nodes half -> Shamir -> deposit to each node (via your NodeClient)
const nodeShares = client.generateShares(nodesHalf, nodes.length, nodeThreshold);
```

### Recovery

```ts
// friends half: guardians decrypt their ECIES shares to the recipient, then combine
const friendsHalf = client.recoverSecret(decryptedFriendShares);

// nodes half: pull shares from nodes (each gated by on-chain canDecrypt), then combine
const nodesHalf = client.recoverSecret(collectedNodeShares);

// rebuild the master key
const K = client.combineKeyTwoHalves(nodesHalf, friendsHalf);
```

## Scripts

```bash
npm install
npm test          # jest: golden vectors + round-trip + node mock
npm run build     # tsc -> lib/
npm run typecheck # tsc --noEmit
npm run harness   # build, then the end-to-end run below
```

### The end-to-end harness

`harness/run.mjs` is the one thing here that does touch the network, against
the scope this package otherwise keeps: it drives a v2 deployment, a relayer
(which pays the gas — no funded key is needed, our keys only sign) and node
custodians, through this SDK's own crypto.

It signs with this package's typed data and nonce keys, reading `version`,
`round` and the nonce right before each signature. It takes the contract
addresses from the environment, refuses to start without them, and stops before
the first signature if either contract's `eip712Domain()` is not the one this
SDK signs for:

```bash
SECRET_RECOVERY_ADDRESS=0x… KEY_REGISTRY_ADDRESS=0x… npm run harness
```

The v2 deployment on Sepolia is `BackitupSecretRecovery`
`0xd9FFD20F2DB9c774b9f0237c4837f52DCbD937a7` and `BackitupKeyRegistry`
`0xAD6bD551224003E621d0B4b640C33eF29a5e9828`.

`CHAIN_ID` and `RPC_URL` override Sepolia and its public RPC. The relayer is a
local one at `http://localhost:3001`, as the demo's; `RELAYER_URL` names a
deployed one — on purpose, because a full run reserves about 22M gas of its
hourly budget. The scenarios send several relayer calls at once, so the relayer
has to choose its dispatcher's nonces itself (`backitup-recovery-backend` from
`fix/relayer-nonce` on), and the six-guardian scenarios need a
`MAX_GAS_PER_CALL` above 3.2M (the backend's default is 6.5M).

The nodes are six local ones on ports 4001-4006 with `NODE_ID` `node-1` …
`node-6`, all watching the v2 `SECRET_RECOVERY_ADDRESS`, which are not started
for you. `NODES` names others instead, as `id@url` pairs like the demo's
`VITE_NODES` (`NODES=node-a@https://…,node-b@https://…`). The node's signed
messages name its id, so before anything is spent the harness asks each node's
`/health` and stops unless it answers under the id it is listed with, for the
contract the run signs for. A scenario that needs more nodes than are listed is
skipped, and recorded as skipped; a run left with nothing to run fails.

It imports the build output, so `npm run build` has to have run — that is what
the script does for you. Every scenario sets a one-hour decrypt window (the
contract's floor) and collects inside it.

A scenario passes when every check it records holds: the secret lands, the
round reads `Voting`, then `TimeLock` with `canDecrypt` false and the nodes
refusing (403 to the recipient, 401/403 to a stranger's signature), then
`Window` with `canDecrypt` true, and the recipient combines the guardians' and
the nodes' halves back into the original key. The veto, revoke and reshare
scenarios check instead that a cancel closes the round, that a revoked secret
cannot be recovered, and that a replaced guardian's share is gone. `ONLY=1,8`
runs a subset; the report goes to `harness/out/`.
