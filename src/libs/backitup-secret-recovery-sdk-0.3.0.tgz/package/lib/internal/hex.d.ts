/** Whole bytes of hex, at least one, with or without a `0x` prefix. */
export declare const isByteHex: (hex: string) => boolean;
