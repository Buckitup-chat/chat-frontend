import { Hex, StealthAddressResult } from '../types';
/**
 * Stealth addresses, ERC-5564 scheme 1 (SECP256k1 with view tags).
 *
 * The structure is the standard's, and it is the part everything else depends
 * on:
 *
 *   s   = p_ephemeral · P_view      (the ECDH is against the **viewing** key)
 *   s_h = h(s)                      (view tag = s_h[0])
 *   P_stealth = P_spend + s_h · G   (**addition**, not multiplication)
 *   p_stealth = p_spend + s_h  (mod n)
 *
 * Two keys, two roles: the viewing key finds a payment, the spending key opens
 * it. A guardian can hand their viewing key to a watcher without handing over
 * the ability to spend, and that separation is the entire reason the standard
 * has two keys rather than one.
 *
 * What the ERC leaves open is the byte encoding — it says "the secret is hashed"
 * without saying how the point is serialised. This is the convention here:
 *
 *   - the shared secret is taken **compressed** (33 bytes) and the leading
 *     parity byte is dropped, so it is keccak256 over the 32-byte x coordinate;
 *   - public keys inside a meta-address are **compressed** (33 bytes each, so a
 *     meta-address is 66 bytes);
 *   - s_h is reduced mod n before use, which changes nothing mathematically
 *     (s_h·G and (s_h mod n)·G are the same point) and keeps a hash that lands
 *     above the curve order from throwing;
 *   - the ephemeral public key in the announcement is compressed too, so every
 *     key that crosses the wire is 33 bytes and only the derived stealth public
 *     key — which never does — is returned uncompressed.
 *
 * `test/stealth.test.ts` carries a vector with literal keys and literal
 * expected values, so an implementer in another language has something exact to
 * compare against rather than a description to interpret.
 */
/** ERC-5564 meta-address string prefix. Stripped before any computation. */
export declare const STEALTH_META_PREFIX = "st:eth:";
/** A meta-address is these two, in this order. */
export interface StealthPublicKeys {
    spendingPublicKey: string;
    viewingPublicKey: string;
}
/** The viewing half: enough to recognise an announcement, not to open it. */
export interface ScanningKeys {
    viewingPrivateKey: string;
    spendingPublicKey: string;
}
/** The spending half: what opening one costs. */
export interface SpendingKeys {
    spendingPrivateKey: string;
    viewingPrivateKey: string;
}
/**
 * `spend || view`, both compressed: the 66-byte blob a guardian publishes to the
 * key registry. Accepts either form of each key so callers do not have to think
 * about it.
 */
export declare const encodeStealthMetaAddress: (keys: StealthPublicKeys) => Hex;
/** The human/interop form: `st:eth:0x<spend><view>`. */
export declare const formatStealthMetaAddress: (metaAddress: Hex) => string;
/** Split a meta-address back into its two compressed keys. Accepts the `st:eth:` form. */
export declare const decodeStealthMetaAddress: (metaAddress: string) => {
    spendingPublicKey: Hex;
    viewingPublicKey: Hex;
};
/**
 * Sender side: derive a fresh stealth address for the guardian who published
 * this meta-address. `ephemeralPrivateKey` exists so a test can pin a vector;
 * leave it out and every call is unlinkable to the last.
 */
export declare const generateStealthAddress: (metaAddress: string, ephemeralPrivateKey?: Hex) => StealthAddressResult;
/**
 * Recipient side, scanning: the address this announcement produces for these
 * keys. Only the viewing key is needed, which is the point of having one.
 *
 * A non-null answer does **not** mean the announcement is yours — every
 * announcement yields some address. It is yours when the returned address
 * equals the announced one, and that comparison is the caller's. Null means
 * only that the view tag ruled the candidate out before the point addition and
 * the hash.
 */
export declare const checkStealthAddress: (keys: ScanningKeys, ephemeralPubKey: string, viewTag?: string) => Hex | null;
/**
 * Recipient side, spending: the private key of a stealth address that is theirs.
 * Both keys arrive in one record rather than as two positional strings — they
 * are the same type, and a swap would be a silently wrong key rather than an
 * error.
 */
export declare const computeStealthKey: (keys: SpendingKeys, ephemeralPubKey: string) => Hex;
