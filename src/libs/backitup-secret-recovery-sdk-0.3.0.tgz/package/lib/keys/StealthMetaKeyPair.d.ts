import { PrivateKeyAccount } from 'viem';
import { Hex } from '../types';
/**
 * A stealth meta key pair: the spending key that opens a stealth address and
 * the viewing key that recognises one. Spending first, matching the order they
 * appear in a meta-address and in every ERC-5564 description of the scheme.
 */
export declare class StealthMetaKeyPair {
    spendingKeyPair: SingleKeyPair;
    viewingKeyPair: SingleKeyPair;
    constructor(keys: {
        spendingPrivateKey: `0x${string}`;
        viewingPrivateKey: `0x${string}`;
    });
    /** The 66-byte `spend || view` blob to publish to a key registry. */
    metaAddress(): Hex;
    /** The same value in the ERC-5564 display form, `st:eth:0x…`. */
    formatMetaAddress(): string;
}
/**
 * Class representing a single key pair.
 * Contains the private key and its associated account.
 */
export declare class SingleKeyPair {
    privatekey: `0x${string}`;
    account: PrivateKeyAccount;
    constructor(privateKey: `0x${string}`);
}
