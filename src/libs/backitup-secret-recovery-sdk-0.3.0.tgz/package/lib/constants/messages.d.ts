export declare const GENERATE_STEALTH_ADDRESS_MESSAGE = "Sign this message to generate your secret keys.\n\nMake sure to sign this message only on a trusted website!\n\nYour PIN: {pin}";
/** The share's SHA-256, hex without `0x`: the digest a deposit signs over. */
export declare const nodeShareDigest: (share: string) => string;
export interface NodeDepositMessage {
    nodeId: string;
    id: string;
    version: number;
    share: string;
    nonce: string;
    ts: number;
}
/** What an owner signs to deposit a node-half share at one node. */
export declare const buildNodeDepositMessage: (m: NodeDepositMessage) => string;
export interface NodeReleaseMessage {
    nodeId: string;
    id: string;
    recipient: string;
    nonce: string;
    ts: number;
}
/** What a recipient signs to ask one node for its node-half share. */
export declare const buildNodeReleaseMessage: (m: NodeReleaseMessage) => string;
