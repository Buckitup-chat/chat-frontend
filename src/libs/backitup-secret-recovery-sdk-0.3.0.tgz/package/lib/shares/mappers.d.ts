import { ShareInput, StealthAddressResult } from '../types';
/** Build a single on-chain `ShareInput` from a stealth result + ciphertext. */
export declare function toShareInput(stealth: StealthAddressResult, shareEncrypted: string): ShareInput;
/**
 * Zip a list of stealth results with their encrypted shares into the
 * `ShareInput[]` array expected by `addSecret` / `reshare`.
 * The two lists must be aligned by index.
 */
export declare function buildShareInputs(stealths: StealthAddressResult[], encryptedShares: string[]): ShareInput[];
