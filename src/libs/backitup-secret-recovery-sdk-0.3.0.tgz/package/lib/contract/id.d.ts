import { Hex } from '../types';
/**
 * Deterministic secret id used by `BackitupSecretRecovery`.
 *
 * Matches the Solidity `keccak256(abi.encode(owner, label))`.
 *
 * @param owner secret owner address
 * @param label human-readable label, unique per owner
 */
export declare function computeId(owner: Hex, label: string): Hex;
