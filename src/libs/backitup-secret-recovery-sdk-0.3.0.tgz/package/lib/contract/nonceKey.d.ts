import { Hex } from '../types';
/**
 * The nonce key every payload about secret `id` is scoped to in
 * `BackitupSecretRecovery`: the Solidity `uint192(uint256(id))`, i.e. the low
 * 192 bits of the id. Read `nonces(signer, nonceKey(id))` to get the value to
 * sign with.
 */
export declare function nonceKey(id: Hex): bigint;
/**
 * The nonce key a registration for `scheme` is scoped to in
 * `BackitupKeyRegistry`: the Solidity `SafeCast.toUint192(scheme)`, which
 * rejects a scheme that does not fit rather than aliasing it onto another.
 */
export declare function registryNonceKey(scheme: number | bigint): bigint;
