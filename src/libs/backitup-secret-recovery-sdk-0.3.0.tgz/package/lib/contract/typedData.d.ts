import { Hex, ShareInput } from '../types';
/**
 * EIP-712 typed data of the Backitup contracts, as data: the domains (less
 * `chainId` / `verifyingContract`, which the caller supplies for its deployment)
 * and the struct definitions, in the exact field order of the `*_TYPEHASH`
 * constants in `BackitupSecretRecovery.sol`, `BackitupKeyRegistry.sol` and
 * `BackitupSigned.sol`. `test/typedData.test.ts` pins each one to the literal
 * type string of the contract.
 *
 * The `{ name, type }[]` records are the input shape of viem's and ethers'
 * `signTypedData`; signing itself stays with the caller.
 *
 * `version` / `round` are hashed by the contract from storage and `nonce` is the
 * signer's keyed one (see `nonceKey`), so a signer reads `getSecret(id)` and
 * `nonces(signer, key)` immediately before signing.
 */
/** Domain of `BackitupSecretRecovery`; the version is the typed-data schema version. */
export declare const SECRET_RECOVERY_DOMAIN: {
    readonly name: "BackitupSecretRecovery";
    readonly version: "2";
};
/** Domain of `BackitupKeyRegistry`; `RegisterKeys` has its original shape. */
export declare const KEY_REGISTRY_DOMAIN: {
    readonly name: "BackitupKeyRegistry";
    readonly version: "1";
};
export declare const TYPES: {
    readonly Share: readonly [{
        readonly name: "stealthAddress";
        readonly type: "address";
    }, {
        readonly name: "ephemeralPubKey";
        readonly type: "bytes";
    }, {
        readonly name: "shareEncrypted";
        readonly type: "bytes";
    }];
    readonly AddSecret: readonly [{
        readonly name: "label";
        readonly type: "string";
    }, {
        readonly name: "shares";
        readonly type: "Share[]";
    }, {
        readonly name: "threshold";
        readonly type: "uint256";
    }, {
        readonly name: "recoveryDelay";
        readonly type: "uint256";
    }, {
        readonly name: "recoveryWindow";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly Reshare: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "shares";
        readonly type: "Share[]";
    }, {
        readonly name: "threshold";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly SetRecoveryPolicy: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "recoveryDelay";
        readonly type: "uint256";
    }, {
        readonly name: "recoveryWindow";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly InitiateRecovery: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly ApproveRecovery: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "candidate";
        readonly type: "address";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly CancelRecovery: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly RevokeSecret: readonly [{
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly name: "version";
        readonly type: "uint256";
    }, {
        readonly name: "round";
        readonly type: "uint256";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly RegisterKeys: readonly [{
        readonly name: "registrant";
        readonly type: "address";
    }, {
        readonly name: "scheme";
        readonly type: "uint256";
    }, {
        readonly name: "stealthMetaAddress";
        readonly type: "bytes";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
    readonly InvalidateNonce: readonly [{
        readonly name: "signer";
        readonly type: "address";
    }, {
        readonly name: "key";
        readonly type: "uint192";
    }, {
        readonly name: "nonce";
        readonly type: "uint256";
    }, {
        readonly name: "deadline";
        readonly type: "uint256";
    }];
};
export type TypedDataPrimaryType = keyof typeof TYPES;
/** The signer's keyed nonce and the signature's expiry, common to every struct. */
interface Signed {
    /** `nonces(signer, key)` at signing time, key prefix included. */
    nonce: bigint;
    /** Unix seconds; at most `MAX_SIGNATURE_LIFETIME` (one day) ahead of the executing block. */
    deadline: bigint;
}
/** Fields every payload about an existing secret carries, hashed by the contract from storage. */
interface SecretBound extends Signed {
    id: Hex;
    /** `getSecret(id).version` at signing time. */
    version: bigint;
    /** `getSecret(id).recoveryRound` at signing time — for `InitiateRecovery`, the round the call increments. */
    round: bigint;
}
export interface AddSecretMessage extends Signed {
    label: string;
    shares: ShareInput[];
    threshold: bigint;
    /** Seconds; `0` selects the contract default. */
    recoveryDelay: bigint;
    /** Seconds; `0` selects the contract default. */
    recoveryWindow: bigint;
}
export interface ReshareMessage extends SecretBound {
    shares: ShareInput[];
    threshold: bigint;
}
export interface SetRecoveryPolicyMessage extends SecretBound {
    recoveryDelay: bigint;
    recoveryWindow: bigint;
}
export type InitiateRecoveryMessage = SecretBound;
export interface ApproveRecoveryMessage extends SecretBound {
    candidate: Hex;
}
export type CancelRecoveryMessage = SecretBound;
export type RevokeSecretMessage = SecretBound;
export interface RegisterKeysMessage extends Signed {
    registrant: Hex;
    scheme: bigint;
    stealthMetaAddress: Hex;
}
export interface InvalidateNonceMessage extends Signed {
    signer: Hex;
    /** The key whose current nonce is burned; `nonce` is that very value. */
    key: bigint;
}
/** The message a signer supplies for each primary type in {@link TYPES}. */
export interface TypedMessages {
    Share: ShareInput;
    AddSecret: AddSecretMessage;
    Reshare: ReshareMessage;
    SetRecoveryPolicy: SetRecoveryPolicyMessage;
    InitiateRecovery: InitiateRecoveryMessage;
    ApproveRecovery: ApproveRecoveryMessage;
    CancelRecovery: CancelRecoveryMessage;
    RevokeSecret: RevokeSecretMessage;
    RegisterKeys: RegisterKeysMessage;
    InvalidateNonce: InvalidateNonceMessage;
}
export {};
