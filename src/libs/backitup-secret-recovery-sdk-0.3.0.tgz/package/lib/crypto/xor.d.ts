import { Hex, TwoHalves } from '../types';
/** Byte-wise XOR of two equal-length hex strings. */
export declare function xorHex(a: string, b: string): Hex;
/**
 * Split a master key K into two information-theoretic halves so that
 * K = nodesHalf XOR friendsHalf. `nodesHalf` is uniformly random, therefore
 * each half on its own reveals nothing about K.
 *
 * @param key master key as a hex string (`0x...`)
 * @param randomFn injectable RNG (defaults to node crypto), for deterministic tests
 */
export declare function splitKeyTwoHalves(key: string, randomFn?: (size: number) => Uint8Array): TwoHalves;
/** Reconstruct K from its two halves: K = nodesHalf XOR friendsHalf. */
export declare function combineKeyTwoHalves(nodesHalf: string, friendsHalf: string): Hex;
