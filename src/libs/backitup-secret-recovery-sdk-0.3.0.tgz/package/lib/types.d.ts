/**
 * Shared types for the Backitup Secret Recovery SDK.
 *
 * Centralised here so that `Hex` and the public interfaces are exported from a
 * single module (avoids duplicate `export *` symbol clashes).
 */
export type Hex = `0x${string}`;
/** Result of deriving a stealth address from a stealth meta-address. */
export interface StealthAddressResult {
    /** 20-byte stealth address (lowercase hex). */
    address: Hex;
    /** 65-byte uncompressed stealth public key. */
    publicKey: Hex;
    /** 65-byte uncompressed ephemeral public key used to derive the address. */
    ephemeralPubKey: Hex;
    /**
     * ERC-5564 view tag: the first byte of the hashed shared secret. A recipient
     * who has it skips the point addition and the hash for every candidate that
     * does not match. Nothing carries it to the recipient yet — `ShareInput` and
     * the on-chain struct have no field for it — so it is returned for senders
     * with a channel of their own.
     */
    viewTag: Hex;
}
/**
 * One guardian share as accepted by `BackitupSecretRecovery.addSecret`.
 * Mirrors the on-chain `ShareInput` struct.
 */
export interface ShareInput {
    /** Guardian stealth address that may decrypt this share. */
    stealthAddress: Hex;
    /** Ephemeral public key needed by the guardian to derive their stealth key. */
    ephemeralPubKey: Hex;
    /** ECIES ciphertext of the Shamir share of the friends-half. */
    shareEncrypted: Hex;
}
/**
 * The lifecycle of a secret's recovery round, as `BackitupSecretRecovery.roundState(id)`
 * returns it. `canDecrypt` is `true` for the elected recipient only in `Window`;
 * `RoundState[state]` is the name.
 */
export declare enum RoundState {
    /** No round in storage. */
    None = 0,
    /** Open; guardians vote, one candidate each. */
    Voting = 1,
    /** Recipient elected; `executeAfter` not reached. */
    TimeLock = 2,
    /** The recipient may decrypt until `executeAfter + recoveryWindow`. */
    Window = 3,
    /** The window has closed; the next initiation replaces the round. */
    Expired = 4
}
/** The two compartments of a secret: K = nodesHalf XOR friendsHalf. */
export interface TwoHalves {
    /** Half held (Shamir-split) by our nodes. */
    nodesHalf: Hex;
    /** Half held (Shamir-split) by friends/guardians. */
    friendsHalf: Hex;
}
/** A node endpoint. For the mock/demo the list is a frontend constant. */
export interface NodeRef {
    id: string;
    url?: string;
}
/** Deposit a node-half Shamir share, bound to a secret id + version. */
export interface NodeAddShareRequest {
    id: Hex;
    version: number;
    /** Shamir share of the nodes-half (hex). */
    share: string;
}
/** Request the node-half share back; gated by on-chain `canDecrypt`. */
export interface NodeGetShareRequest {
    id: Hex;
    /** Address that wants to receive the share (owner or recoveryRecipient). */
    recipient: Hex;
}
/**
 * Minimal node API: a node only stores a node-half share and returns it iff
 * `BackitupSecretRecovery.canDecrypt(recipient, id) == true`.
 */
export interface NodeClient {
    add(node: NodeRef, req: NodeAddShareRequest): Promise<void>;
    get(node: NodeRef, req: NodeGetShareRequest): Promise<string>;
}
/** Predicate that mirrors the on-chain `canDecrypt(account, id)` view. */
export type CanDecryptFn = (account: Hex, id: Hex) => Promise<boolean> | boolean;
