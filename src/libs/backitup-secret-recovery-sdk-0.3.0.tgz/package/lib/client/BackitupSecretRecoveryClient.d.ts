import { Account, WalletClient } from 'viem';
import { StealthMetaKeyPair } from '../keys/StealthMetaKeyPair';
import { Hex, ShareInput, StealthAddressResult, TwoHalves } from '../types';
type WagmiWalletClient = Omit<WalletClient, 'account'> & {
    account: Account | undefined;
};
/** The shares given do not combine into the secret they were split from. */
export declare class ShareIntegrityError extends Error {
    constructor();
}
/**
 * Crypto client for the Backitup compartmented secret-recovery scheme.
 *
 * Reuses the proven primitives from the original `buckitup-sdk`
 * (stealth meta keys, Shamir SSS, ECIES, stealth address derivation) and adds
 * the two-half split (K = K_nodes XOR K_friends) plus helpers to build the
 * on-chain `ShareInput[]` and the deterministic secret id.
 *
 * This client is network-agnostic: it never touches the chain or nodes. Wire it
 * up with a contract client (EIP-712) and a {@link NodeClient} separately.
 */
export declare class BackitupSecretRecoveryClient {
    /**
     * Generates the signature used to derive a StealthMetaKeyPair.
     * @param pin salt mixed into the signed message
     * @param walletClient connected wallet
     */
    generateBaseSignature: (pin: string, walletClient: WalletClient | WagmiWalletClient) => Promise<string>;
    /**
     * Derives a StealthMetaKeyPair from a 65-byte signature.
     * @param signature 0x-prefixed signature
     */
    generateKeysFromSignature: (signature: string) => Promise<StealthMetaKeyPair>;
    /**
     * Split a secret into `numShares` shares with the given recovery threshold,
     * at least 2: with 1, every share is the whole secret.
     */
    generateShares: (secret: string, numShares: number, threshold: number) => string[];
    /**
     * Split a secret and encrypt each share to the matching public key (ECIES).
     * Output order matches the order of `publicKeys`.
     */
    generateSharesEncrypted: (secret: string, numShares: number, threshold: number, publicKeys: string[]) => Promise<string[]>;
    /**
     * Reconstruct a secret from at least `threshold` shares. Throws
     * {@link ShareIntegrityError} rather than return a wrong secret.
     */
    recoverSecret: (shares: string[]) => string;
    /** Decrypt one ECIES-encrypted share with its private key. */
    decryptShare: (encryptedShare: string, privateKey: string) => Promise<string>;
    /**
     * The stealth functions are exported from the package root as well; these
     * aliases exist so a consumer holding the client does not have to import them
     * separately. They are the same functions, not forwarding wrappers — a
     * wrapper would re-type the signature and then keep forwarding the old
     * arguments after the module changed.
     */
    generateStealthAddress: (metaAddress: string, ephemeralPrivateKey?: Hex) => StealthAddressResult;
    checkStealthAddress: (keys: import("../keys/stealth").ScanningKeys, ephemeralPubKey: string, viewTag?: string) => Hex | null;
    computeStealthKey: (keys: import("../keys/stealth").SpendingKeys, ephemeralPubKey: string) => Hex;
    /** Split a master key K into nodes/friends halves (K = nodesHalf XOR friendsHalf). */
    splitKeyTwoHalves: (key: string, randomFn?: (size: number) => Uint8Array) => TwoHalves;
    /** Reconstruct K from its two halves. */
    combineKeyTwoHalves: (nodesHalf: string, friendsHalf: string) => Hex;
    /** Deterministic secret id: keccak256(abi.encode(owner, label)). */
    computeId: (owner: Hex, label: string) => Hex;
    /** Build a single on-chain `ShareInput`. */
    toShareInput: (stealth: StealthAddressResult, shareEncrypted: string) => ShareInput;
    /** Build the `ShareInput[]` array for `addSecret` / `reshare`. */
    buildShareInputs: (stealths: StealthAddressResult[], encryptedShares: string[]) => ShareInput[];
}
export {};
